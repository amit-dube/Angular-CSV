<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

function deleteData(){

		if(!empty($_GET['id'])){
			$id= $_GET['id']; 
		}else{
			$arr['suc']="id filed is required to delete the recored";
			header("Content-type: application/json");
			http_response_code(200);
			echo json_encode($arr);
			exit;
		}
		
		// Open file
		$file = fopen('data.csv', 'r');
		// Headers
		$headers = fgetcsv($file);
		// Rows
		$data = [];
		while (($row = fgetcsv($file)) !== false){
			$item = [];
			foreach ($row as $key => $value)
			$item[$headers[$key]] = $value ?: null;
			$data[] = $item;
		}
		// Close file
		fclose($file);
		$datalabel = array("id","name","state","zip","amount","qty","item");		
		foreach($data as $subKey => $subArray){
			if($subArray['id'] == $id){
				unset($data[$subKey]);
				// Loop through file pointer and a line
				$output = fopen('data.csv', 'w');   
				fputcsv($output, $datalabel); 
				if(count($data)>0){
					foreach ($data as $record){
						fputcsv($output, $record);
					}
					$arr['suc']="Record deleted successfully";
					header("Content-type: application/json");
					http_response_code(200);
					echo json_encode($arr);
					exit;
				}else{
					$arr['suc']="No Records Found";
					header("Content-type: application/json");
					http_response_code(200);
					echo json_encode($arr);		
				}
				fclose($output); 

			}
		}
	}

deleteData();


?>