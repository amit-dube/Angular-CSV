<?php
function getinfo(){
	echo "a";
}

getinfo();

?>