<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$request_method = $_SERVER['REQUEST_METHOD'];
//$request_data = explode('/', trim($_SERVER['PATH_INFO'],'/'));

if($request_method == 'POST'){
$get_input = file_get_contents('php://input');

	$newdata = json_decode($get_input,true);
	$file = fopen('data.csv', 'r');
	// Headers
	$headers = fgetcsv($file);
	// Rows
	$data = [];
	while (($row = fgetcsv($file)) !== false){
		$item = [];
		foreach ($row as $key => $value)
		$item[$headers[$key]] = $value ?: null;
		$data[] = $item;
	}
	// Close file
	fclose($file);
	$newid=count($data)+1;
	$newarr=array('id'=>$newid);
		$newdata = array_merge($newarr,$newdata);
	
	$data[] = $newdata;
	/*echo "<pre>";
	print_r($data);
	echo "<pre>";
	exit;*/
	$datalabel = array("id","name","state","zip","amount","qty","item");		
	foreach($data as $subKey => $subArray){
			// Loop through file pointer and a line
			$output = fopen('data.csv', 'w');   
			fputcsv($output, $datalabel); 
			if(count($data)>0){
				foreach ($data as $record){			
					fputcsv($output, $record);
				}
			}else{
				$record = array("No Records Found");
				fputcsv($output, $record);
			}
			fclose($output);
		}

}
?>