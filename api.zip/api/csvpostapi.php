<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

function addData(){
	$request_method = $_SERVER['REQUEST_METHOD'];
	if($request_method == 'POST'){
	$get_input = file_get_contents('php://input');
	$errors = array();
		$newdata = json_decode($get_input,true);
		if(empty($newdata['name'])){
			$errors['succ'] = 'Name field required';
			header("Content-type: application/json");
			http_response_code(200);
			echo json_encode($errors);
			exit;
		}else if(strlen($newdata['name'])<3){
			$errors['succ'] = 'Name field must be 2 charectors long.';
			header("Content-type: application/json");
			http_response_code(200);
			echo json_encode($errors);
			exit;
		}
		
		if(empty($newdata['state'])){
			$errors['succ'] = 'State field required';
			header("Content-type: application/json");
			http_response_code(200);
			echo json_encode($errors);
			exit;
		}else if(strlen($newdata['state'])<1){
			$errors['succ'] = 'state field must be 2 charectors long.';
			header("Content-type: application/json");
			http_response_code(200);
			echo json_encode($errors);
			exit;
		}
		if(empty($newdata['zip'])){
			$errors['succ'] = 'Zip field required';
			header("Content-type: application/json");
			http_response_code(200);
			echo json_encode($errors);
			exit;
		}else if(!preg_match("/^[0-9]+$/", $newdata['zip'])){
			$errors['succ'] = 'zip field must be numeric.';
			header("Content-type: application/json");
			http_response_code(200);
			echo json_encode($errors);
			exit;
		}
		if(empty($newdata['amount'])){
			$errors['amount'] = 'Amount field required';
			header("Content-type: application/json");
			http_response_code(200);
			echo json_encode($errors);
			exit;
		}else if(!preg_match("/^\d+\.?\d*$/", $newdata['amount'])){
			$errors['succ'] = 'Amount must be in digit.';
			header("Content-type: application/json");
			http_response_code(200);
			echo json_encode($errors);
			exit;
		}
		if(empty($newdata['qty'])){
			$errors['succ'] = 'Quantity field required';
			header("Content-type: application/json");
			http_response_code(200);
			echo json_encode($errors);
			exit;
		}else if(!preg_match("/^[0-9]+$/", $newdata['qty'])){
			$errors['succ'] = 'Quantity must be in digits.';
			header("Content-type: application/json");
			http_response_code(200);
			echo json_encode($errors);
			exit;
		}
		if(empty($newdata['item'])){
			$errors['succ'] = 'Item field required';
			header("Content-type: application/json");
			http_response_code(200);
			echo json_encode($errors);
			exit;
		}else if(strlen( $newdata['item'] ) < 2){
			$errors['succ'] = 'Please enter the characters.';
			header("Content-type: application/json");
			http_response_code(200);
			echo json_encode($errors);
			exit;
		}else{
		
			$file = fopen('data.csv', 'r');
			// Headers
			$headers = fgetcsv($file);
			// Rows
			$data = [];
			while (($row = fgetcsv($file)) !== false){
				$item = [];
				foreach ($row as $key => $value)
				$item[$headers[$key]] = $value ?: null;
				$data[] = $item;
			}
			// Close file
			fclose($file);
			// Genrate the next row id
			$newid=count($data)+1;
			$newarr=array('id'=>$newid);
			$newdata = array_merge($newarr,$newdata);
			
			$data[] = $newdata;
			//Add the new record in CSV 
			$datalabel = array("id","name","state","zip","amount","qty","item");		
			foreach($data as $subKey => $subArray){
					// Loop through file pointer and a line
					$output = fopen('data.csv', 'w');   
					fputcsv($output, $datalabel); 
					if(count($data)>0){
						foreach ($data as $record){			
							fputcsv($output, $record);
						}
					}else{
						$record = array("No Records Found");
						fputcsv($output, $record);
					}
					fclose($output);
				}
			$errors['succ'] = 'Data inserted successfully.';
			header("Content-type: application/json");
			http_response_code(200);
			echo json_encode($errors);
			exit;
		}
	}else{
		$errors['strErrorDesc'] = 'Method not supported';
        header("Content-type: application/json");
		http_response_code(422);
		echo json_encode($errors);
	}

}


addData();
?>