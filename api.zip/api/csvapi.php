<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

if(isset($_GET['fl']) && $_GET['fl'] == 'get'){
	if(isset($_GET['id'])){
		$id = $_GET['id'];
		// Open file
		$file = fopen('data.csv', 'r');
		// Headers
		$headers = fgetcsv($file);
		// Rows
		$data = [];
		while (($row = fgetcsv($file)) !== false){
			$item = [];
			foreach ($row as $key => $value)
			$item[$headers[$key]] = $value ?: null;
			$data[] = $item;
		}
		// Close file
		fclose($file);
	if(count($data)>0){
		foreach($data as $subKey => $subArray){
			if($subArray['id'] == $id){			
				if(count($data)>0){
					$json_arr[] = array(
					'id'=> $subArray['id'],

					'name'=> $subArray['name'] ?? '',

					'state'=> $subArray['state'] ?? '', 

					'zip'=> $subArray['zip'] ?? '',

					'amount'=> $subArray['amount'] ?? '',

					'qty'=> $subArray['qty'] ?? '', 

					'item'=> $subArray['item'] ?? '');
					 header("Content-type: application/json");
					 http_response_code(200);
					echo json_encode($json_arr);
					exit;
				}else{
					$json_arr['succ']="No Records Found";
					 header("Content-type: application/json");
					 http_response_code(200);
					echo json_encode($json_arr);
					
				}
			}
		}
	}else{
			$json_arr['succ']="No Records Found";
			header("Content-type: application/json");
			 http_response_code(200);
			echo json_encode($json_arr);
		}
	}else{
			// Open file
			$file = fopen('data.csv', 'r');
			// Headers
			$headers = fgetcsv($file);
			// Rows
			$data = [];
			while (($row = fgetcsv($file)) !== false){
				$item = [];
				foreach ($row as $key => $value)
				$item[$headers[$key]] = $value ?: null;
				$data[] = $item;
			}
			// Close file
			fclose($file);
			//print_r($data);
			
			header("Content-type: application/json");
			 http_response_code(200);
			echo json_encode($data);
			exit;
			//return $data;
		}
}

if($_GET['fl'] && $_GET['fl'] == 'delete'){
		if(isset($_GET['id'])){
		$id = $_GET['id'];
	}else{
		$id = 0;
	}
	
// Open file

$file = fopen('data.csv', 'r');
// Headers
$headers = fgetcsv($file);
// Rows
$data = [];
while (($row = fgetcsv($file)) !== false){
	$item = [];
	foreach ($row as $key => $value)
	$item[$headers[$key]] = $value ?: null;
	$data[] = $item;
}
// Close file
fclose($file);

$datalabel = array("id","name","state","zip","amount","qty","item");		
foreach($data as $subKey => $subArray){
	if($subArray['id'] == $id){
		unset($data[$subKey]);
		// Loop through file pointer and a line
		$output = fopen('data.csv', 'w');   
		fputcsv($output, $datalabel); 
		if(count($data)>0){
			foreach ($data as $record){
				fputcsv($output, $record);
			}
			$arr['suc']="Record deleted successfully";
			header("Content-type: application/json");
			http_response_code(200);
			echo json_encode($arr);
			exit;
		}else{
			$arr['suc']="No Records Found";
			header("Content-type: application/json");
			http_response_code(200);
			echo json_encode($arr);		
		}
		fclose($output); 

	}
}


}

?>