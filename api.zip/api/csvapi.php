<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

if(isset($_GET['fl']) && $_GET['fl'] == 'get'){
	// Open file
	$file = fopen('data.csv', 'r');
	// Headers
	$headers = fgetcsv($file);
	// Rows
	$data = [];
	while (($row = fgetcsv($file)) !== false){
		$item = [];
		foreach ($row as $key => $value)
		$item[$headers[$key]] = $value ?: null;
		$data[] = $item;
	}
	// Close file
	fclose($file);
	//print_r($data);
	echo json_encode($data);
	exit;
	//return $data;
}


if($_GET['fl'] && $_GET['fl'] == 'delete'){
	if(isset($_GET['fl'])){
		$id = $_GET['id'];
	}else{
		$id = 0;
	}
	
	// Open file
$file = fopen('data.csv', 'r');
// Headers
$headers = fgetcsv($file);
// Rows
$data = [];
while (($row = fgetcsv($file)) !== false){
	$item = [];
	foreach ($row as $key => $value)
	$item[$headers[$key]] = $value ?: null;
	$data[] = $item;
}
// Close file
fclose($file);

$datalabel = array("id","name","state","zip","amount","qty","item");		
foreach($data as $subKey => $subArray){
	if($subArray['id'] == $id){
		unset($data[$subKey]);
		// Loop through file pointer and a line
		$output = fopen('data.csv', 'w');   
		fputcsv($output, $datalabel); 
		if(count($data)>0){
			foreach ($data as $record){			
				fputcsv($output, $record);
			}
		}else{
			$record = array("No Records Found");
			fputcsv($output, $record);
		}
		fclose($output); 

	}
}
$arr['suc']=1;
echo json_encode($arr);
exit;
}

?>