<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

function getInfo(){
	$requestMethod = $_SERVER["REQUEST_METHOD"]; $strErrorDesc = '';

	if($requestMethod == 'GET'){

	if(isset($_GET['id'])){
		$id = $_GET['id'];
		// Open file
		$file = fopen('data.csv', 'r');
		// Headers
		$headers = fgetcsv($file);
		// Rows
		$data = [];
		while (($row = fgetcsv($file)) !== false){
			$item = [];
			foreach ($row as $key => $value)
			$item[$headers[$key]] = $value ?: null;
			$data[] = $item;
		}
		// Close file
		fclose($file);
	if(count($data)>0){
		foreach($data as $subKey => $subArray){
			if($subArray['id'] == $id){			
				if(count($data)>0){
					$json_arr[] = array(
					'id'=> $subArray['id'],

					'name'=> $subArray['name'] ?? '',

					'state'=> $subArray['state'] ?? '', 

					'zip'=> $subArray['zip'] ?? '',

					'amount'=> $subArray['amount'] ?? '',

					'qty'=> $subArray['qty'] ?? '', 

					'item'=> $subArray['item'] ?? '');
					 header("Content-type: application/json");
					 http_response_code(200);
					echo json_encode($json_arr);
					exit;
				}else{
					$json_arr['succ']="No Records Found";
					 header("Content-type: application/json");
					 http_response_code(200);
					echo json_encode($json_arr);
					
				}
			}
		}
	}else{
			$json_arr['succ']="No Records Found";
			header("Content-type: application/json");
			 http_response_code(200);
			echo json_encode($json_arr);
		}
	}else{
			// Return the full record in json format
			$file = fopen('data.csv', 'r');
			// Headers
			$headers = fgetcsv($file);
			// Rows
			$data = [];
			while (($row = fgetcsv($file)) !== false){
				$item = [];
				foreach ($row as $key => $value)
				$item[$headers[$key]] = $value ?: null;
				$data[] = $item;
			}
			// Close file
			fclose($file);
			//print_r($data);
			
			header("Content-type: application/json");
			http_response_code(200);
			echo json_encode($data);
			exit;
			//return $data;
		}
	}else{
		$strErrorDesc = 'Method not supported';
        header("Content-type: application/json");
		http_response_code(422);
		json_encode(array('error' => $strErrorDesc));
	}
}

getInfo();
?>